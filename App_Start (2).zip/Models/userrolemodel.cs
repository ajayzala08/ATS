﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ATS2019_2.Models
{
    public class userrolemodel
    {
        public decimal uid { get; set; }
        public string role { get; set; }
    }
}